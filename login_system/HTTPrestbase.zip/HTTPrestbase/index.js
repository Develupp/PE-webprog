"use strict";
// Init .env variables
require("dotenv").config();

require("./src/main.js");
